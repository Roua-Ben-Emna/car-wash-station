package com.isi.carwash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCarWashApplicationTests {

	@Test
	void contextLoads() {
	}

}
