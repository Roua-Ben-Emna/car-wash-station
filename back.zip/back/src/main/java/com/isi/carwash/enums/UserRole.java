package com.isi.carwash.enums;

public enum UserRole {
    MANAGER,
    USER
}
