package com.isi.carwash.enums;

public enum CarSize {
    SMALL, // Petite
    MEDIUM, // Moyenne
    LARGE;// Grande
}