package com.isi.carwash.enums;

public enum WashType {
    EXTERIOR,
    INTERIOR,
    EXTERIOR_INTERIOR;
}
